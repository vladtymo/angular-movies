import { Component, OnInit } from '@angular/core';
import { Movie } from '../movie';

@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {

  date: Date = new Date(Date.now());
  d: number = Date.now();
  movie: Movie = {
    title: "Fast & Furious 5",
    rating: 8.7,
    year: 2011
  }

  constructor() { }

  ngOnInit(): void {
  }

}
