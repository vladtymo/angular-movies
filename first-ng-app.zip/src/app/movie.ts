export class Movie {
    title: string;
    rating: number;
    year: number;
}